export class Employee {
    constructor(public id:number=0, public first_name:string='', 
        public last_name:string='', public email:string=''){}
}
